# Aplikasi Jasa Laundry
* Aplikasi jasa laundry berbasis desktop yang dibangun menggunakan Netbeans 
* Memiliki user login dengan role admin dan super admin yang mana super admin memiliki akses untuk menambah user, melihat data admin, data pelanggan, dan data transaksi. Sedangkan role admin hanya dapat menambahkan transaksi

# Screenshot
<p align="center">
  <img src="https://user-images.githubusercontent.com/21327758/70906492-1671c180-2039-11ea-9e98-f7f01861da93.JPG" width="430" />
  <img src="https://user-images.githubusercontent.com/21327758/70906527-29849180-2039-11ea-87cf-0623a61d81e5.JPG" width="430" />
</p>
<p align="center">
  <img src="https://user-images.githubusercontent.com/21327758/70906512-225d8380-2039-11ea-98f0-071b9e2bd21d.JPG" width="430" />
  <img src="https://user-images.githubusercontent.com/21327758/70906510-21c4ed00-2039-11ea-948c-7cc4cd4a10c1.JPG" width="430" />
</p>
<p align="center">
  <img src="https://user-images.githubusercontent.com/21327758/70906524-28536480-2039-11ea-9be5-0ddab57c7f63.JPG" width="430" />
  <img src="https://user-images.githubusercontent.com/21327758/70906523-28536480-2039-11ea-8469-4de34ec7739d.JPG" width="430" />
</p>

<p align="center">
  <img src="https://user-images.githubusercontent.com/21327758/70906529-2a1d2800-2039-11ea-9995-c0b25ddc0ac6.JPG" width="430" />
  <img src="https://user-images.githubusercontent.com/21327758/70907200-dca1ba80-203a-11ea-9759-3d26d780082d.JPG" width="430" />
</p>
