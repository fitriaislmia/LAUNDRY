package controller;

/** @author faizaaulia */

public class Driver {
    
    public static void main(String[] args) {
        new LoginController();
    }
}
